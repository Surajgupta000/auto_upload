const axios = require('axios');
const fs = require('fs');
const path = require('path');

const deployToVercel = async (req, res) => {
  const filePath = path.join(__dirname, '../../uploads', req.file.filename);

  try {
    const response = await axios.post('https://api.vercel.com/v13/deployments', {
      name: req.file.originalname,
      files: [
        {
          file: req.file.originalname,
          data: fs.readFileSync(filePath, 'base64'),
        },
      ],
      projectSettings: {
        framework: null,
      },
    }, {
      headers: {
        Authorization: `Bearer ${process.env.VERCEL_TOKEN}`,
      },
    });

    res.status(200).send({ message: 'Project deployed to Vercel successfully', url: response.data.url });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
};

module.exports = { deployToVercel };
