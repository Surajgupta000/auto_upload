const path = require('path');
const { readFileAsBase64 } = require('../utils/fileHelper');

let octokit;

const initializeOctokit = async () => {
  const { Octokit } = await import("@octokit/rest");
  octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });
};

const uploadToGitHub = async (req, res) => {
  const { owner, repo } = req.body;
  const filePath = path.join(__dirname, '../../uploads', req.file.filename);

  try {
    if (!octokit) {
      await initializeOctokit();
    }
    const content = readFileAsBase64(filePath);
    await octokit.repos.createOrUpdateFileContents({
      owner,
      repo,
      path: req.file.originalname,
      message: 'Initial commit',
      content,
    });

    res.status(200).send({ message: 'Project uploaded to GitHub successfully' });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
};

module.exports = { uploadToGitHub };
