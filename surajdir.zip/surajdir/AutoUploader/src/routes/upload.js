const express = require('express');
const multer = require('multer');
const path = require('path');
const { uploadToGitHub } = require('../controllers/github');
const { deployToVercel } = require('../controllers/vercel');

const router = express.Router();

// Set up Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Save files to 'uploads' directory
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });

// Route to handle file uploads
router.post('/', upload.single('project'), async (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded!');
  }

  try {
    await uploadToGitHub(req, res);
    await deployToVercel(req, res);
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

module.exports = router;
