const fs = require('fs');
const path = require('path');

const readFileAsBase64 = (filePath) => {
  return fs.readFileSync(filePath, 'base64');
};

module.exports = { readFileAsBase64 };
